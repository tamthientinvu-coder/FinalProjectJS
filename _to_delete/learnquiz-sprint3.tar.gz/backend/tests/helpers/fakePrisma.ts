/* Prisma giả lập trong bộ nhớ - CHỈ dùng để kiểm thử, không nằm trong sản phẩm.
   Điểm quan trọng: nó TÔN TRỌNG `select`/`include` giống Prisma thật,
   nhờ vậy kiểm chứng được việc `isCorrect` có bị lọt ra ngoài hay không. */

type Row = Record<string, any>;
export const db = {
  courses: [] as Row[], lessons: [] as Row[], enrollments: [] as Row[],
  lessonProgress: [] as Row[], quizzes: [] as Row[], questions: [] as Row[],
  choices: [] as Row[], submissions: [] as Row[], answers: [] as Row[],
};

const rel: Record<string, Record<string, (r: Row) => any>> = {
  lesson: {
    course: (r) => db.courses.find((c) => c.id === r.courseId),
    quiz: (r) => db.quizzes.find((q) => q.lessonId === r.id),
    progresses: (r) => db.lessonProgress.filter((p) => p.lessonId === r.id),
  },
  quiz: {
    lesson: (r) => db.lessons.find((l) => l.id === r.lessonId),
    questions: (r) => db.questions.filter((q) => q.quizId === r.id),
    submissions: (r) => db.submissions.filter((s) => s.quizId === r.id),
  },
  question: { choices: (r) => db.choices.filter((c) => c.questionId === r.id) },
  quizSubmission: {
    quiz: (r) => db.quizzes.find((q) => q.id === r.quizId),
    answers: (r) => db.answers.filter((a) => a.submissionId === r.id),
  },
  course: {}, enrollment: {}, lessonProgress: {}, choice: {}, answer: {},
};

function sortRows(rows: Row[], orderBy?: Row) {
  if (!orderBy) return rows;
  const [field, dir] = Object.entries(orderBy)[0] as [string, string];
  return [...rows].sort((a, b) => (a[field] < b[field] ? -1 : a[field] > b[field] ? 1 : 0) * (dir === "desc" ? -1 : 1));
}

function matches(row: Row, where?: Row): boolean {
  if (!where) return true;
  return Object.entries(where).every(([k, v]) => {
    if (v && typeof v === "object" && !Array.isArray(v)) {
      // khóa unique ghép, ví dụ studentId_courseId: { studentId, courseId }
      return Object.entries(v).every(([kk, vv]) => row[kk] === vv);
    }
    return row[k] === v;
  });
}

/** Áp dụng select/include đúng như Prisma: select = CHỈ các field liệt kê. */
function project(model: string, row: Row | undefined, args: Row = {}): any {
  if (!row) return row;
  const relations = rel[model] ?? {};

  if (args.select) {
    const out: Row = {};
    for (const [key, spec] of Object.entries<any>(args.select)) {
      if (key === "_count") {
        out._count = {};
        for (const relName of Object.keys(spec.select ?? {})) {
          out._count[relName] = (relations[relName]?.(row) ?? []).length;
        }
      } else if (spec === true) {
        out[key] = row[key];
      } else if (spec && typeof spec === "object") {
        const value = relations[key]?.(row);
        out[key] = Array.isArray(value)
          ? sortRows(value, spec.orderBy).map((v) => project(childModel(model, key), v, spec))
          : project(childModel(model, key), value, spec);
      }
    }
    return out;
  }

  // include = toàn bộ field vô hướng + các quan hệ được liệt kê
  const out: Row = { ...row };
  for (const [key, spec] of Object.entries<any>(args.include ?? {})) {
    if (key === "_count") {
      out._count = {};
      for (const relName of Object.keys(spec.select ?? {})) {
        out._count[relName] = (relations[relName]?.(row) ?? []).length;
      }
      continue;
    }
    const value = relations[key]?.(row);
    out[key] = Array.isArray(value)
      ? sortRows(value, spec?.orderBy).map((v) => project(childModel(model, key), v, spec === true ? {} : spec))
      : project(childModel(model, key), value, spec === true ? {} : spec);
  }
  return out;
}

function childModel(parent: string, key: string): string {
  const map: Record<string, string> = {
    course: "course", quiz: "quiz", questions: "question", choices: "choice",
    lesson: "lesson", submissions: "quizSubmission", answers: "answer", progresses: "lessonProgress",
  };
  return map[key] ?? key;
}

/** Bản đồ quan hệ để hỗ trợ "nested create" nhiều tầng như Prisma thật. */
const nested: Record<string, Record<string, { store: Row[]; fk: string; model: string }>> = {
  quiz: { questions: { store: db.questions, fk: "quizId", model: "question" } },
  question: { choices: { store: db.choices, fk: "questionId", model: "choice" } },
  quizSubmission: { answers: { store: db.answers, fk: "submissionId", model: "answer" } },
};

function createRow(model: string, store: Row[], data: Row, nextId: () => number): Row {
  const childSpecs = nested[model] ?? {};
  const scalars: Row = {};
  const children: [string, any][] = [];

  for (const [key, value] of Object.entries(data)) {
    if (childSpecs[key]) children.push([key, value]);
    else scalars[key] = value;
  }

  const row: Row = { id: nextId(), ...scalars };
  store.push(row);

  for (const [key, spec] of children) {
    const meta = childSpecs[key];
    const items = Array.isArray(spec?.create) ? spec.create : spec?.create ? [spec.create] : [];
    for (const item of items) {
      createRow(meta.model, meta.store, { ...item, [meta.fk]: row.id }, nextId);
    }
  }
  return row;
}

function makeModel(model: string, store: Row[], nextId: () => number) {
  return {
    findUnique: async (args: Row) => project(model, store.find((r) => matches(r, args.where)), args),
    findFirst: async (args: Row = {}) => project(model, sortRows(store.filter((r) => matches(r, args.where)), args.orderBy)[0], args),
    findMany: async (args: Row = {}) =>
      sortRows(store.filter((r) => matches(r, args.where)), args.orderBy).map((r) => project(model, r, args)),
    count: async (args: Row = {}) => store.filter((r) => matches(r, args.where)).length,
    create: async (args: Row) => project(model, createRow(model, store, args.data, nextId), args),
    update: async (args: Row) => {
      const row = store.find((r) => matches(r, args.where));
      if (!row) return null;
      const childSpecs = nested[model] ?? {};
      for (const [key, value] of Object.entries<any>(args.data)) {
        if (childSpecs[key]) {
          const meta = childSpecs[key];
          const items = Array.isArray(value?.create) ? value.create : value?.create ? [value.create] : [];
          for (const item of items) createRow(meta.model, meta.store, { ...item, [meta.fk]: row.id }, nextId);
        } else {
          row[key] = value;
        }
      }
      return project(model, row, args);
    },
    delete: async (args: Row) => {
      const i = store.findIndex((r) => matches(r, args.where));
      return i >= 0 ? store.splice(i, 1)[0] : null;
    },
    deleteMany: async (args: Row = {}) => {
      const keep = store.filter((r) => !matches(r, args.where));
      const removed = store.length - keep.length;
      store.length = 0;
      store.push(...keep);
      return { count: removed };
    },
  };
}

let idSeq = 9000;
const nextId = () => ++idSeq;

const fakePrisma: any = {
  course: makeModel("course", db.courses, nextId),
  lesson: makeModel("lesson", db.lessons, nextId),
  enrollment: makeModel("enrollment", db.enrollments, nextId),
  lessonProgress: makeModel("lessonProgress", db.lessonProgress, nextId),
  quiz: makeModel("quiz", db.quizzes, nextId),
  question: makeModel("question", db.questions, nextId),
  choice: makeModel("choice", db.choices, nextId),
  quizSubmission: makeModel("quizSubmission", db.submissions, nextId),
  answer: makeModel("answer", db.answers, nextId),
  $transaction: async (arg: any) => (typeof arg === "function" ? arg(fakePrisma) : Promise.all(arg)),
  $queryRaw: async () => [{ "?column?": 1 }],
};

export default fakePrisma;
