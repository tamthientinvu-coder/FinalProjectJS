/* Kiểm tra bảng định tuyến thật của Express + vòng đời một request qua middleware. */
process.env.DATABASE_URL = "postgresql://x:x@localhost:5432/x";
process.env.JWT_ACCESS_SECRET = "test_access_secret";
process.env.JWT_REFRESH_SECRET = "test_refresh_secret";
process.env.NODE_ENV = "test";

import fakePrisma, { db } from "./helpers/fakePrisma";
import { ok, section, report } from "./helpers/assert";
const prismaPath = require.resolve("../src/utils/prisma");
require.cache[prismaPath] = {
  id: prismaPath, filename: prismaPath, loaded: true, exports: { default: fakePrisma, __esModule: true },
} as any;

const app = require("../src/app").default;
const http = require("http");
const { signAccessToken } = require("../src/utils/jwt");


// ---- Liệt kê route đã đăng ký ----
function collectRoutes(): string[] {
  const out: string[] = [];
  const walk = (stack: any[], prefix: string) => {
    for (const layer of stack) {
      if (layer.route) {
        const methods = Object.keys(layer.route.methods).filter((m) => layer.route.methods[m]).map((m) => m.toUpperCase());
        for (const m of methods) out.push(`${m} ${prefix}${layer.route.path}`);
      } else if (layer.name === "router" && layer.handle?.stack) {
        const src = layer.regexp.source
          .replace("^\\/", "/").replace("\\/?(?=\\/|$)", "").replace(/\\\//g, "/").replace(/\$$/, "");
        walk(layer.handle.stack, prefix + (src === "/(?:/)?" ? "" : src));
      }
    }
  };
  walk(app._router.stack, "");
  return out;
}

const routes = collectRoutes();
section("H. BẢNG ĐỊNH TUYẾN THỰC TẾ");
routes.filter((r) => r.includes("quiz") || r.includes("submission")).forEach((r) => console.log("   " + r));

const expected = [
  "GET /api/v1/lessons/:id/quiz",
  "GET /api/v1/lessons/:id/quiz/editor",
  "PUT /api/v1/lessons/:id/quiz",
  "PATCH /api/v1/quiz/:id",
  "DELETE /api/v1/quiz/:id",
  "POST /api/v1/quiz/:id/submit",
  "GET /api/v1/quiz/:id/submissions/me",
  "GET /api/v1/submissions/:id",
];
console.log("");
for (const e of expected) ok(`đã đăng ký: ${e}`, routes.includes(e), `\n      có: ${routes.filter(r=>r.includes("quiz")||r.includes("submission")).join(" | ")}`);
ok("tổng số endpoint /api/v1", routes.filter((r) => r.startsWith("GET /api/v1") || r.startsWith("POST /api/v1") || r.startsWith("PATCH /api/v1") || r.startsWith("PUT /api/v1") || r.startsWith("DELETE /api/v1")).length >= 25);

// ---- Gọi HTTP thật ----
function seed() {
  Object.values(db).forEach((a: any[]) => (a.length = 0));
  db.courses.push({ id: 1, title: "JS", instructorId: 2, status: "published" });
  db.lessons.push({ id: 1, courseId: 1, title: "Bài 1", order: 1, content: "nd", videoUrl: null });
  db.enrollments.push({ id: 100, studentId: 4, courseId: 1 });
  db.quizzes.push({ id: 10, lessonId: 1, title: "KT", passScore: 70, maxAttempts: null });
  db.questions.push({ id: 1000, quizId: 10, text: "Câu hỏi 1?", order: 1 });
  [1, 2, 3, 4].forEach((c) => db.choices.push({ id: 1000 * 10 + c, questionId: 1000, text: `Đ${c}`, isCorrect: c === 1 }));
}

function request(server: any, method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any; raw: string }> {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : undefined;
    const req = http.request(
      { host: "127.0.0.1", port: server.address().port, method, path,
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(data ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data) } : {}) } },
      (res: any) => {
        let raw = "";
        res.on("data", (c: any) => (raw += c));
        res.on("end", () => { try { resolve({ status: res.statusCode, body: JSON.parse(raw), raw }); } catch { resolve({ status: res.statusCode, body: null, raw }); } });
      }
    );
    req.on("error", reject);
    if (data) req.write(data);
    req.end();
  });
}

(async () => {
  seed();
  const server = app.listen(0);
  await new Promise((r) => server.once("listening", r));

  const studentToken = signAccessToken({ id: 4, email: "s@x.vn", role: "student" });
  const strangerToken = signAccessToken({ id: 5, email: "o@x.vn", role: "student" });

  section("I. GỌI HTTP THẬT QUA TOÀN BỘ CHUỖI MIDDLEWARE");

  const health = await request(server, "GET", "/health");
  ok("GET /health -> 200 ok", health.status === 200 && health.body.status === "ok");

  const noAuth = await request(server, "GET", "/api/v1/lessons/1/quiz");
  ok("không gửi token -> 401", noAuth.status === 401, `nhận ${noAuth.status}`);

  const quizRes = await request(server, "GET", "/api/v1/lessons/1/quiz", studentToken);
  ok("học viên lấy đề -> 200", quizRes.status === 200, `nhận ${quizRes.status}: ${quizRes.raw.slice(0, 200)}`);
  ok("PHẢN HỒI HTTP THẬT không chứa isCorrect", !quizRes.raw.includes("isCorrect"), `\n      body: ${quizRes.raw.slice(0, 400)}`);

  const editorRes = await request(server, "GET", "/api/v1/lessons/1/quiz/editor", studentToken);
  ok("học viên gọi endpoint soạn đề -> 403", editorRes.status === 403, `nhận ${editorRes.status}`);

  const badId = await request(server, "GET", "/api/v1/lessons/abc/quiz", studentToken);
  ok("id không phải số -> 400", badId.status === 400, `nhận ${badId.status}`);

  const badBody = await request(server, "POST", "/api/v1/quiz/10/submit", studentToken, { answers: [] });
  ok("bài làm rỗng -> 400 kèm thông báo tiếng Việt",
    badBody.status === 400 && String(badBody.raw).includes("Bài làm không được rỗng"), `nhận ${badBody.status}: ${badBody.raw.slice(0,200)}`);

  const dup = await request(server, "POST", "/api/v1/quiz/10/submit", studentToken,
    { answers: [{ questionId: 1000, choiceId: 10001 }, { questionId: 1000, choiceId: 10002 }] });
  ok("trùng câu hỏi -> 400", dup.status === 400, `nhận ${dup.status}`);

  const submitRes = await request(server, "POST", "/api/v1/quiz/10/submit", studentToken, { answers: [{ questionId: 1000, choiceId: 10001 }] });
  ok("nộp bài -> 201 và 100 điểm", submitRes.status === 201 && submitRes.body?.data?.submission?.score === 100,
    `nhận ${submitRes.status}: ${submitRes.raw.slice(0, 200)}`);
  const subId = submitRes.body?.data?.submission?.id;

  const stealer = await request(server, "GET", `/api/v1/submissions/${subId}`, strangerToken);
  ok("người khác xem bài làm -> 403", stealer.status === 403, `nhận ${stealer.status}`);

  const notFound = await request(server, "GET", "/api/v1/khong-ton-tai", studentToken);
  ok("endpoint không tồn tại -> 404", notFound.status === 404, `nhận ${notFound.status}`);

  const massAssign = await request(server, "POST", "/api/v1/quiz/10/submit", studentToken,
    { answers: [{ questionId: 1000, choiceId: 10002 }], score: 100 });
  ok("gửi kèm score=100 -> server VẪN tự chấm ra 0",
    massAssign.status === 201 && massAssign.body?.data?.submission?.score === 0,
    `nhận điểm ${massAssign.body?.data?.submission?.score}`);

  const headers = await new Promise<any>((resolve) => {
    http.get({ host: "127.0.0.1", port: server.address().port, path: "/health" }, (r: any) => { r.resume(); resolve(r.headers); });
  });
  ok("helmet đã bật (có x-content-type-options)", headers["x-content-type-options"] === "nosniff");
  ok("không lộ x-powered-by", headers["x-powered-by"] === undefined);

  server.close();
  report("api.test.ts");
  process.exit(0);
})().catch((e) => { console.error("LỖI NGOÀI DỰ KIẾN:", e); process.exit(1); });
