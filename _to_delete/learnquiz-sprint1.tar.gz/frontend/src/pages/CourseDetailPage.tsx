import { useEffect, useState } from "react";
import {
  Box,
  Paper,
  Typography,
  Chip,
  Stack,
  Button,
  Alert,
  Skeleton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Tooltip,
} from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import QuizIcon from "@mui/icons-material/Quiz";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useParams, Link as RouterLink } from "react-router-dom";
import { courseApi } from "../api/courseApi";
import { handleApiError } from "../utils/handleApiError";
import { useAuth } from "../context/AuthContext";
import {
  LEVEL_LABEL,
  STATUS_COLOR,
  STATUS_LABEL,
  type CourseDetail,
} from "../types/course";

const FALLBACK_THUMB = "https://placehold.co/1200x400/e0e0e0/757575?text=LearnQuiz";

export default function CourseDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();

  const [course, setCourse] = useState<CourseDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    courseApi
      .getById(Number(id))
      .then((res) => setCourse(res.data.data))
      .catch((err) => setError(handleApiError(err)))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <Stack spacing={2}>
        <Skeleton variant="rounded" height={240} />
        <Skeleton variant="text" height={50} />
        <Skeleton variant="rounded" height={200} />
      </Stack>
    );
  }

  if (error || !course) {
    return (
      <Stack spacing={2}>
        <Alert severity="error">{error || "Không tìm thấy khóa học"}</Alert>
        <Box>
          <Button startIcon={<ArrowBackIcon />} component={RouterLink} to="/courses">
            Về danh sách khóa học
          </Button>
        </Box>
      </Stack>
    );
  }

  const isOwner = user?.id === course.instructorId;

  return (
    <Stack spacing={3}>
      <Box>
        <Button startIcon={<ArrowBackIcon />} component={RouterLink} to="/courses" size="small">
          Danh sách khóa học
        </Button>
      </Box>

      <Paper sx={{ overflow: "hidden" }}>
        <Box
          component="img"
          src={course.thumbnail || FALLBACK_THUMB}
          alt={course.title}
          sx={{ width: "100%", height: { xs: 180, md: 280 }, objectFit: "cover", display: "block" }}
        />

        <Box sx={{ p: 3 }}>
          <Stack direction="row" spacing={1} sx={{ mb: 1.5, flexWrap: "wrap" }} useFlexGap>
            {course.category && <Chip size="small" color="primary" label={course.category.name} />}
            <Chip size="small" variant="outlined" label={LEVEL_LABEL[course.level]} />
            {/* Nhãn trạng thái chỉ có ý nghĩa với chủ sở hữu và admin */}
            {(isOwner || user?.role === "admin") && (
              <Chip size="small" color={STATUS_COLOR[course.status]} label={STATUS_LABEL[course.status]} />
            )}
          </Stack>

          <Typography variant="h4" gutterBottom>
            {course.title}
          </Typography>

          <Typography color="text.secondary" sx={{ mb: 2 }}>
            Giảng viên: <strong>{course.instructor.name}</strong> · {course._count.lessons} bài học ·{" "}
            {course._count.enrollments} học viên đã đăng ký
          </Typography>

          <Typography sx={{ whiteSpace: "pre-line" }}>
            {course.description || "Khóa học chưa có mô tả."}
          </Typography>

          {course.status === "rejected" && isOwner && course.rejectReason && (
            <Alert severity="warning" sx={{ mt: 2 }}>
              Khóa học bị từ chối. Lý do: {course.rejectReason}
            </Alert>
          )}

          <Box sx={{ mt: 3 }}>
            <Tooltip title="Chức năng đăng ký học sẽ hoàn thành ở Sprint 2">
              <span>
                <Button variant="contained" size="large" disabled>
                  Đăng ký học
                </Button>
              </span>
            </Tooltip>
            {isOwner && (
              <Button
                variant="outlined"
                size="large"
                sx={{ ml: 2 }}
                component={RouterLink}
                to={`/instructor/courses/${course.id}/edit`}
              >
                Sửa khóa học
              </Button>
            )}
          </Box>
        </Box>
      </Paper>

      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Nội dung khóa học
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          Nội dung chi tiết của từng bài chỉ mở sau khi đăng ký khóa học.
        </Typography>
        <Divider />

        {course.lessons.length === 0 ? (
          <Typography color="text.secondary" sx={{ py: 3, textAlign: "center" }}>
            Khóa học chưa có bài học nào.
          </Typography>
        ) : (
          <List>
            {course.lessons.map((lesson) => (
              <ListItem key={lesson.id} divider>
                <ListItemIcon>
                  <LockIcon color="disabled" />
                </ListItemIcon>
                <ListItemText
                  primary={`Bài ${lesson.order}. ${lesson.title}`}
                  secondary={lesson.quiz ? "Có quiz cuối bài" : "Không có quiz"}
                />
                {lesson.quiz && <QuizIcon color="secondary" />}
              </ListItem>
            ))}
          </List>
        )}
      </Paper>
    </Stack>
  );
}
