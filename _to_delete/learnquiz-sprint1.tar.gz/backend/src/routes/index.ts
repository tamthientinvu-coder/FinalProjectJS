import { Router } from "express";
import authRoutes from "./authRoutes";
import categoryRoutes from "./categoryRoutes";
import courseRoutes from "./courseRoutes";

const router = Router();

router.use("/auth", authRoutes);
router.use("/categories", categoryRoutes);
router.use("/courses", courseRoutes);

// Sprint 2+: router.use("/lessons", lessonRoutes) · router.use("/enrollments", enrollmentRoutes)
// Sprint 3+: router.use("/quiz", quizRoutes)
// Sprint 4+: router.use("/admin", adminRoutes) · router.use("/users", userRoutes)
// Sprint 5+: router.use("/ai", aiRoutes)

export default router;
