import { Router } from "express";
import * as courseController from "../controllers/courseController";
import { authenticate, authenticateOptional } from "../middleware/authenticate";
import { authorize } from "../middleware/authorize";
import { validate, validateQuery } from "../middleware/validate";
import { validateId } from "../middleware/validateId";
import { createCourseSchema, updateCourseSchema, courseQuerySchema } from "../schemas/courseSchema";

const router = Router();

// 1) Danh sách khóa học đã duyệt - công khai, có lọc và phân trang
router.get("/", validateQuery(courseQuerySchema), courseController.list);

// 2) Khóa học của tôi - PHẢI khai báo TRƯỚC "/:id",
//    nếu không Express sẽ khớp "mine" vào :id và validateId báo lỗi 400.
router.get("/mine", authenticate, authorize("instructor", "admin"), courseController.listMine);

// 3) Chi tiết - khách xem được khóa đã duyệt; khóa nháp chỉ chủ sở hữu và admin
router.get("/:id", validateId(), authenticateOptional, courseController.getById);

// 4) Tạo mới - giảng viên
router.post(
  "/",
  authenticate,
  authorize("instructor", "admin"),
  validate(createCourseSchema),
  courseController.create
);

// 5) Sửa - chủ sở hữu hoặc admin (kiểm tra trong service)
router.patch(
  "/:id",
  validateId(),
  authenticate,
  authorize("instructor", "admin"),
  validate(updateCourseSchema),
  courseController.update
);

// 6) Gửi đi duyệt - draft | rejected -> pending
router.post(
  "/:id/submit",
  validateId(),
  authenticate,
  authorize("instructor", "admin"),
  courseController.submitForReview
);

// 7) Xóa - chặn nếu đã có học viên đăng ký
router.delete(
  "/:id",
  validateId(),
  authenticate,
  authorize("instructor", "admin"),
  courseController.remove
);

export default router;
