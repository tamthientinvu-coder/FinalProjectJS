import { createBrowserRouter } from "react-router-dom";
import MainLayout from "../components/layout/MainLayout";
import HomePage from "../pages/HomePage";
import LoginPage from "../pages/LoginPage";
import RegisterPage from "../pages/RegisterPage";
import DashboardPage from "../pages/DashboardPage";
import CourseListPage from "../pages/CourseListPage";
import CourseDetailPage from "../pages/CourseDetailPage";
import MyCoursesPage from "../pages/MyCoursesPage";
import LearnPage from "../pages/LearnPage";
import InstructorCoursesPage from "../pages/instructor/InstructorCoursesPage";
import CourseFormPage from "../pages/instructor/CourseFormPage";
import LessonEditorPage from "../pages/instructor/LessonEditorPage";
import AdminCategoriesPage from "../pages/admin/AdminCategoriesPage";
import ForbiddenPage from "../pages/ForbiddenPage";
import NotFoundPage from "../pages/NotFoundPage";
import ProtectedRoute from "./ProtectedRoute";

const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />,
    children: [
      // --- Công khai ---
      { index: true, element: <HomePage /> },
      { path: "login", element: <LoginPage /> },
      { path: "register", element: <RegisterPage /> },
      { path: "courses", element: <CourseListPage /> },
      { path: "courses/:id", element: <CourseDetailPage /> },

      // --- Cần đăng nhập ---
      {
        path: "dashboard",
        element: (
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        ),
      },

      // --- Học viên ---
      {
        path: "my-courses",
        element: (
          <ProtectedRoute>
            <MyCoursesPage />
          </ProtectedRoute>
        ),
      },
      {
        path: "learn/:courseId",
        element: (
          <ProtectedRoute>
            <LearnPage />
          </ProtectedRoute>
        ),
      },

      // --- Giảng viên ---
      {
        path: "instructor/courses",
        element: (
          <ProtectedRoute roles={["instructor", "admin"]}>
            <InstructorCoursesPage />
          </ProtectedRoute>
        ),
      },
      {
        path: "instructor/courses/new",
        element: (
          <ProtectedRoute roles={["instructor", "admin"]}>
            <CourseFormPage />
          </ProtectedRoute>
        ),
      },
      {
        path: "instructor/courses/:id/edit",
        element: (
          <ProtectedRoute roles={["instructor", "admin"]}>
            <CourseFormPage />
          </ProtectedRoute>
        ),
      },
      {
        path: "instructor/courses/:id/lessons",
        element: (
          <ProtectedRoute roles={["instructor", "admin"]}>
            <LessonEditorPage />
          </ProtectedRoute>
        ),
      },

      // --- Quản trị ---
      {
        path: "admin/categories",
        element: (
          <ProtectedRoute roles={["admin"]}>
            <AdminCategoriesPage />
          </ProtectedRoute>
        ),
      },

      // --- Sprint 3: quiz/:lessonId, quiz-result/:submissionId ---
      // --- Sprint 4: admin/courses, admin/users ---

      { path: "403", element: <ForbiddenPage /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
]);

export default router;
