import { Router } from "express";
import * as lessonController from "../controllers/lessonController";
import { authenticate } from "../middleware/authenticate";
import { authorize } from "../middleware/authorize";
import { validate } from "../middleware/validate";
import { validateId } from "../middleware/validateId";
import { updateLessonSchema, completeLessonSchema } from "../schemas/lessonSchema";

const router = Router();

// Xem nội dung bài học - phải đăng nhập, service kiểm tra tiếp đã enroll và đã mở khóa chưa
router.get("/:id", validateId(), authenticate, lessonController.getLessonContent);

// Sửa / xóa - chủ sở hữu khóa học hoặc admin
router.patch(
  "/:id",
  validateId(),
  authenticate,
  authorize("instructor", "admin"),
  validate(updateLessonSchema),
  lessonController.update
);
router.delete(
  "/:id",
  validateId(),
  authenticate,
  authorize("instructor", "admin"),
  lessonController.remove
);

// Đánh dấu hoàn thành - học viên đã đăng ký
router.patch(
  "/:id/complete",
  validateId(),
  authenticate,
  validate(completeLessonSchema),
  lessonController.markComplete
);

export default router;
